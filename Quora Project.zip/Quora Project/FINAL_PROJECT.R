setwd("D:/Data Scientist/Final Project")
getwd()


library(ggplot2) # Data visualization
library(readr) # CSV file I/O, e.g. the read_csv function
library(stringr)
library(data.table)
library(tm)

quora <-fread("train.csv")

str(quora)
head(quora)
tail(quora)
dim(quora)

quora[,2:3] = NULL
setnames(quora, c("id","q1","q2","is_duplicate"))

quora$id <- as.integer(quora$id)
levels(as.factor(quora$is_duplicate))
quora$is_duplicate[quora$is_duplicate == "0"] <- 0
quora$is_duplicate[quora$is_duplicate != "0"] <- 1
quora$is_duplicate <- factor(quora$is_duplicate)

# calculate number of common words in both questions.
# "This is question one." and "This is question two." have three words in common

word_match<- function(x)
{
  # same as aove function. Here we are returning the ratio instead of count.
  w1 <- x[1]
  w2 <- x[2]
  
  w1 <- tolower(w1)
  w2 <- tolower(w2)
  w1 <- gsub("[^A-Za-z0-9]"," ",w1)
  w2 <- gsub("[^A-Za-z0-9]"," ",w2)
  w1 <- gsub("[\t ]"," ",w1)
  w2 <- gsub("[\t ]"," ",w2)
  w1 <- gsub('[[:punct:]]', '', w1)
  w2 <- gsub('[[:punct:]]', '', w2)
  w1 <- str_trim(w1)
  w2 <- str_trim(w2)
  w1 <- str_split(w1," ")
  w2 <- str_split(w2," ")
  w1 <- w1[[1]]
  w2 <- w2[[1]]
  
  count <- 0
  
  for(word1 in w1)
    for(word2 in w2)
    {
      if(word1 == word2)
      {
        count <- count + 1
      }
      
    }
  
  return(count)
  
  
}
similar_count <- apply(quora[,2:3], 1, word_match)
quora$similar_words <- similar_count

# calculate ratio of common words to avarage of total words in the questions.
# The ratio for above given example is 3/4. Pretty similar question. Can be a duplicate.
word_match_ratio <- function(x)
{
  # same as aove function. Here we are returning the ratio instead of count.
  w1 <- x[1]
  w2 <- x[2]
  
  w1 <- tolower(w1)
  w2 <- tolower(w2)
  w1 <- gsub("[^A-Za-z0-9]"," ",w1)
  w2 <- gsub("[^A-Za-z0-9]"," ",w2)
  w1 <- gsub("[\t ]"," ",w1)
  w2 <- gsub("[\t ]"," ",w2)
  w1 <- gsub('[[:punct:]]', '', w1)
  w2 <- gsub('[[:punct:]]', '', w2)
  w1 <- str_trim(w1)
  w2 <- str_trim(w2)
  w1 <- str_split(w1," ")
  w2 <- str_split(w2," ")
  w1 <- w1[[1]]
  w2 <- w2[[1]]
  
  count <- 0
  
  for(word1 in w1)
    for(word2 in w2)
    {
      if(word1 == word2)
      {
        count <- count + 1
      }
      
    }
  
  # length of each question is the number of words contained in it.
  average_length <- (length(w1)+length(w2))/2 
  match_ratio <- count/average_length
  
  return(match_ratio)
}

ratio <- apply(quora[,2:3], 1, word_match_ratio)
quora$ratio <- ratio


# visualization

ggplot(quora, aes(x  = similar_words)) + geom_histogram(color = "black") +
  scale_x_continuous(limits = c(0,quantile(quora$similar_words,0.99)))

ggplot(quora, aes(x  = ratio)) + geom_histogram(color = "black") +
  scale_x_continuous(limits = c(0,quantile(quora$ratio,0.99)))

# predictive modelling

library(randomForest)
library(caTools)
library(caret)


# split data

set.seed(4)
split <- sample.split(quora$is_duplicate, SplitRatio = 0.75)
train <- subset(quora, split == TRUE)
test <- subset(quora, split == FALSE)

train <- train[ ,4:6]
test <- test[ ,4:6]



# Decision trees
library("rpart") 
tree_model <- rpart(is_duplicate ~ ., data = train, method="class")
tree_predict <- predict(tree_model, test[,-1],type="class")
confusionMatrix(test$is_duplicate, tree_predict)


# random forest

set.seed(10)
rf_model <- randomForest(is_duplicate ~ ., data = train, importance = TRUE,
                         ntree = 500, nodesize = 50)
rf_predict <- predict(rf_model, test)
confusionMatrix(test$is_duplicate, rf_predict)

# logistic regression
library(ROCR)
glm_model <- glm(is_duplicate ~ ., data = train,family = "binomial")
glm_predict <- predict(glm_model,test, type = "response")
#confusion matrix
table(test$is_duplicate, glm_predict>0.5)

#ROC Curve: Receiver Operating Characteristic(ROC) summarizes the model's performance
#by evaluating the trade offs between true positive rate (sensitivity)
#and false positive rate(1- specificity). 
#ROCR Curve
library(ROCR)
p=prediction(glm_predict,test$is_duplicate)
prf <- performance(p,"tpr","fpr")
plot(prf)


